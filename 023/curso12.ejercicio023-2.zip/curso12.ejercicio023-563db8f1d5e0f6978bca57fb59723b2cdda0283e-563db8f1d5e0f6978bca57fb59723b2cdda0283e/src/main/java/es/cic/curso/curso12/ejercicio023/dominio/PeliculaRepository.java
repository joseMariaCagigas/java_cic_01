package es.cic.curso.curso12.ejercicio023.dominio;

public interface PeliculaRepository extends IRepository<Long, Pelicula>{

}