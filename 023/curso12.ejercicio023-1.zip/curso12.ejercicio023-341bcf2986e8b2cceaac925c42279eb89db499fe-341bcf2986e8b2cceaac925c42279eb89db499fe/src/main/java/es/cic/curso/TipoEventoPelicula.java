package es.cic.curso;

public enum TipoEventoPelicula {
	CREAR_ACTUALIZAR,
	BORRAR
}
