package es.cic.curso;

public interface PeliculaDetallePresenter {

	void crearActualizar();

	void borrar();

	PeliculaDetalleVista getVista();

}