package es.cic.curso;

public interface PeliculaListener {
	public void onPeliculaEvent(PeliculaEvent peliculaEvent);
}
